library(testthat)
library(nbsample)

test_check("nbsample")

